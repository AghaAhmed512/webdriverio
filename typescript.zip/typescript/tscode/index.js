"use strict";
let age = 45;
if (age < 50)
    age += 10;
console.log(age);
//# sourceMappingURL=index.js.map