// let age: number = 45;
// if (age < 50)
//     age += 10;
//     console.log(age)

let sales: number = 123456;         //Number type
let course: string = 'Typescript'; // String type
let isCompleted:boolean = false   //  Boolean type
let level;                        //  any type

function render(document:number){
    console.log(document)
}
render(2);

let number:number[] = []; // array of numbers
let str:string[] = [];    // array of strings

let user: [number, string] = [1,'agha']; // tuple (have exactly fix length)

//enums: list of related constants

const enum Size {Small, Medium, Large};
let mySize:Size = Size.Large; 
console.log(mySize)

///functions
function calculateTex(income:number):number{
    return 0;
}

 